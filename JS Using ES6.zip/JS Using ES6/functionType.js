//normal function
display1(); //we can call normal func before declaration
function display1() {
    document.write("Normal Function Declaration")
}
display1();

//expression style function with name
let display3 = function display2() {        //variable name is func name considered
    document.write("<br>Expression style function with name")
}

//display2();       //create error
display3();

//display4(); //we can't call exp style func before declaration
//expression style function without name
let display4 = function() {        //variable name is func name considered
    document.write("<br>Expression style function without name")
}

display4();