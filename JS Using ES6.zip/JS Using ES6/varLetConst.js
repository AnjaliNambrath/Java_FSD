var a=10;
a=20;
var a = 30;
document.write("<br> Value of a "+a)

let b=10;
b=20;
//let b=30;     //error
document.write("<br> Value of b "+b)

for(var i=0;i<=100;i++){

}
document.write("<br> Value of i "+i)

for(let j=0;j<=100;j++){

}
//document.write("<br> Value of j "+j)    //error

const k=1000;
//k=2000;       //error, cant change k value 