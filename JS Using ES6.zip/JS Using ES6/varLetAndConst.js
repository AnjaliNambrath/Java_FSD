var a=10;
a=20;
var a=30;
document.write("<br> Value of a "+a)

let b=10;
b=20;
//let b=30;             // Error 
document.write("<br> Value of a "+b)
for(var i=0;i<=100000;i++){

}
document.write("<br/>Value of i is "+i);
for(let j=0;j<=100000;j++){

}
//document.write("<br/> Value of j is "+j)
const k=1000;
//k=2000;           can't change 