package com.testing;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeMethod;

import static org.testng.Assert.assertEquals;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;

public class LoginPageTest {
	WebDriver wd;
	@BeforeMethod
	  public void beforeMethod() {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\anjal\\eclipse-workspace\\JavaFSD_Phase5\\chromedriver.exe");
		wd = new ChromeDriver();
	  }
	
  @Test
  public void loginPageTest() {
	  wd.get("http://127.0.0.1:5500/login.html");
	  WebElement emailRef = wd.findElement(By.id("n1"));
		emailRef.sendKeys("raj@gmail.com");
		WebElement passRef = wd.findElement(By.id("n2"));
		passRef.sendKeys("123");
		WebElement subButRef = wd.findElement(By.id("b1"));
		subButRef.click();
		Alert alertRef = wd.switchTo().alert();		//give alert box ref
		String result = alertRef.getText();
		alertRef.accept();
		assertEquals(result, "Successful Login");
  }
  
  @AfterMethod
  public void afterMethod() {
	  wd.close();
  }

}
