package com.service;

import static org.testng.Assert.assertEquals;

import org.testng.annotations.Ignore;
import org.testng.annotations.Test;

import com.bean.Account;

public class AccountServiceTest {

  @Test
  //@Ignore
  public void createAccountTest() {
    //throw new RuntimeException("Test not implemented");
	  AccountService ac = new AccountService();
	  Account acc1 = new Account(100,"Ravi",400);
	  String result = ac.createAccount(acc1);
	  assertEquals(result, "Min Mount must be 500");
	  Account acc2 = new Account(102,"Mahesh",2700);
	  String result2 = ac.createAccount(acc2);
	  assertEquals(result2, "Account created");
//	  Account acc3 = new Account(100,"Mahesh",10000);
//	  String result3 = ac.createAccount(acc3);
//	  assertEquals(result3, "Account Didnt Created");
  }

  @Test
  //@Ignore
  public void depositTest() {
    //throw new RuntimeException("Test not implemented");
	  AccountService ac = new AccountService();
	  Account acc1 = new Account();
	  acc1.setAccno(100);
	  acc1.setAmount(60000);
	  String result1 = ac.deposit(acc1);
	  assertEquals(result1, "You cant deposit 50000 at a time");
	  Account acc2 = new Account();
	  acc2.setAccno(1000);
	  acc2.setAmount(600);
	  String result2 = ac.deposit(acc2);
	  assertEquals(result2, "didnt deposit");
	  Account acc3 = new Account();
	  acc3.setAccno(102);
	  acc3.setAmount(200);
	  String result3 = ac.deposit(acc3);
	  assertEquals(result3, "Deposited");

  }

  @Test
  //@Ignore
  public void findBalanceTest() {
    //throw new RuntimeException("Test not implemented");
	  AccountService ac = new AccountService();
	  String balanceDetails1 = ac.findBalance(100);
	  String balanceDetails2 = ac.findBalance(102);
	  String balanceDetails3 = ac.findBalance(1000);
	  assertEquals(balanceDetails1.contains("700"),true);
//	  assertEquals(balanceDetails2, "Your account balance is 1700.0");
//	  assertEquals(balanceDetails3, "Account no doesnt exist");
  }

  @Test
  //@Ignore
  public void withdrawnTest() {
    //throw new RuntimeException("Test not implemented");
	  AccountService ac = new AccountService();
	  Account acc1 = new Account();
	  acc1.setAccno(100);
	  acc1.setAmount(200);
	  String result1 = ac.withdrawn(acc1);
	  assertEquals(result1, "you cant withdraw, maintain minimum balance");
	  
	  Account acc2 = new Account();
	  acc2.setAccno(1000);
	  acc2.setAmount(200);
	  String result2 = ac.withdrawn(acc2);
	  assertEquals(result2, "Invalid Account no");
	  
	  Account acc3 = new Account();
	  acc3.setAccno(102);
	  acc3.setAmount(200);
	  String result3 = ac.withdrawn(acc3);
	  assertEquals(result3, "Withdrawn Successfully");
  }
}
