package com.service;

import org.testng.annotations.Test;

public class SampleTest {
	@Test
	  public void f1() {
		  System.out.println("While Testing! F1 - secondclass");
	  }
	  @Test
	  public void f2() {
		  System.out.println("While Testing! F2 - secondclass");
	  }
}
