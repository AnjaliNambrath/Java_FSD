package com.service;

import com.bean.Account;
import com.dao.AccountDao;

public class AccountService {
	AccountDao ad = new AccountDao();
	public String createAccount(Account account) {
		if(account.getAmount()<500) {
			return "Min Mount must be 500";
		}
		else if(ad.createAccount(account)>0) {
			return "Account created";
		}
		else {
			return "Account Didnt Created";
		}
	}
	
	public String findBalance(int accno) {
		//return "ur bal is 5000";
		//return "Account no doesnt exist";
		float balamout = ad.findBalance(accno);
		if(balamout>=0) {
			return "Your account balance is "+balamout;
		}else if(balamout==-1) {
			return "Account no doesnt exist";
		}else {
			return "Exception Generated";
		}
				
	}
	
	public String withdrawn(Account account) {
		//return "withdrawn successfully";
		//return "You cant withdraw";
		
		float balanceamount = ad.findBalance(account.getAccno());
		if(balanceamount==-1) {
			return "Invalid Account no";
		}
		else if(balanceamount-account.getAmount()>500) {
			if(ad.withdrawn(account)>0) {
				return "Withdrawn Successfully";
			}else {
				return "Didnt witdraw";
			}
		}else {
			return "you cant withdraw, maintain minimum balance";
		}
	}
	
	public String deposit(Account account) {
		//return "deposit successfully";
		//return "You cant deposit";
		if(account.getAmount()>50000) {
			return "You cant deposit 50000 at a time";
		}else if(ad.deposit(account)>0) {
			return "Deposited";
		}else {
			return "didnt deposit";
		}
	}
	
	
}
