package com.service;

import java.util.ArrayList;
import java.util.List;

import com.bean.User;

public class UserService {
	
	public String checkUser(String emailid, String password) {
		if(emailid.equals("anu@gmail.com") && password.equals("123")) {
			return "success";
		}
		else {
			return "failure";
		}
	}
	
	public User getUser() {
		User usr = new User();
		usr.setUsername("siva@gmail.com");
		usr.setPassword("1234");
		return usr;
	}
	
	public User getName() {
		User usr = new User();
		usr.setUsername("siva@gmail.com");
		return usr;
	}
	
	public User getpassword() {
		User usr = new User();
		usr.setPassword("1234");
		return usr;
	}
	
	public List<User> getAllUser(){
		List<User> list = new ArrayList<User>();
		User usr = new User();
		usr.setUsername("sona@gmail.com");
		usr.setPassword("6789");
		usr.setUsername("arun@gmail.com");
		usr.setPassword("3456");
		usr.setUsername("piya@gmail.com");
		usr.setPassword("7890");
		return list;		
	}

}
