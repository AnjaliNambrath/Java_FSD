package com.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.bean.UserFeedback;
import com.service.UserService;

@RestController
public class UserController {

	@Autowired
	UserService userService;
	
	@RequestMapping(value = "feedbackDB",method = RequestMethod.GET,produces = MediaType.APPLICATION_JSON_VALUE)
	public List<UserFeedback> getAllFeedback(){
		return userService.getAllFeedback();
	}
	
	@RequestMapping(value = "storefeedback",method = RequestMethod.POST,consumes = MediaType.APPLICATION_JSON_VALUE)
	public String storeFeedback(@RequestBody UserFeedback usr) {
		return userService.storeFeedback(usr);
	}
}
