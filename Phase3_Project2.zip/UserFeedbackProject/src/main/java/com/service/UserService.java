package com.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bean.UserFeedback;
import com.dao.UserDao;

@Service
public class UserService {
	
	@Autowired
	UserDao userDao;
	
	public List<UserFeedback> getAllFeedback(){
		return userDao.getAllFeedBack();
	}
	
	public String storeFeedback(UserFeedback usr) {
		if(userDao.storeFeedback(usr)>0) {
			return "Record Stored";
		}
		else {
			return "Record didnt Stored";
		}
	}
	
}
