package com;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

public class DemoTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//		Employee emp1 = new Employee();
//		emp1.display();
		
		Resource rs = new ClassPathResource("beans.xml"); //load xml file
		BeanFactory bb = new XmlBeanFactory(rs);		//getting beanfactory reference
//		Employee emp = (Employee)bb.getBean("emp1");
//		emp.display();
		
//		Employee emp1 = (Employee)bb.getBean("emp1");
//		emp1.display();
//		
//		Employee employee2 = (Employee)bb.getBean("emp2");
//		employee2.display();	
//		
//		Employee employee = (Employee)bb.getBean("emp2");
//		employee.display();
		
//		Employee employee1 = (Employee)bb.getBean("emp1");
//		employee1.display();									
//		System.out.println(employee1);	//will call toString()
		
//		Employee employee4 = (Employee)bb.getBean("emp3");
//		employee4.display();									
//		System.out.println(employee4);	//DI using parameterized constructor
		
//		Employee employee5 = (Employee)bb.getBean("emp4");
//		employee5.display();									
//		System.out.println(employee5);	//pulling through setter
		
		Address address1 = (Address)bb.getBean("add1");
		System.out.println(address1);
		
		Employee emplo = (Employee)bb.getBean("emp8");
		System.out.println(emplo);

	}

}
