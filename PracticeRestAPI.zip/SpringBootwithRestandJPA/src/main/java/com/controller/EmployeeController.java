package com.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.bean.Employee;
import com.service.EmployeeService;

@RestController
public class EmployeeController {
	@Autowired
	EmployeeService employeeService;
	
	@RequestMapping(value = "employee",method = RequestMethod.GET,produces = MediaType.APPLICATION_JSON_VALUE)
	public Employee getEmployeeInfo() {
		Employee emp = new Employee(100,"Ajay",12000);
		return emp;
	}
	
	@RequestMapping(value = "employees",method = RequestMethod.GET,produces = MediaType.APPLICATION_JSON_VALUE)
	public List<Employee> getAllEmployeeInfo() {
		List<Employee> list = new ArrayList<Employee>();
		list.add(new Employee(100,"Ajay",12000));
		list.add(new Employee(200,"Vjay",22000));
		list.add(new Employee(200,"Bjay",52000));
		return list;
	}
	@RequestMapping(value = "employeesDB",method = RequestMethod.GET,produces = MediaType.APPLICATION_JSON_VALUE)
	public List<Employee> getAllEmployeeInfoDB() {
		return employeeService.getAllEmployee();
	}
	//localhost:8080/employeesDBbyID/100		//using path param
	@RequestMapping(value = "employeesDBbyID/{id}",method = RequestMethod.GET,produces = MediaType.APPLICATION_JSON_VALUE)
	public Employee findEmployeeById(@PathVariable("id") int id) {
		return employeeService.findEmployeeById(id);
	}
	//{"id":1,"name":"Raj","salary":12000.0}
	@RequestMapping(value = "storeEmployee",consumes = MediaType.APPLICATION_JSON_VALUE, method=RequestMethod.POST)
	public String storeEmployee(@RequestBody Employee emp) {	//scan the value from request body in the form JSON
		return employeeService.storeEmployee(emp);
	}
}
