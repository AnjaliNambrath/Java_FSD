package com.controller;

import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController		//@controller+@ResponseBody
public class SampleController {
	@RequestMapping(value = "say",method = RequestMethod.GET)
	public String sayHelo() {
		return "Welcome to Spring Boot with RestAPI";
	}
	
	@RequestMapping(value = "html",method = RequestMethod.GET,produces = MediaType.TEXT_HTML_VALUE)
	public String sayHtml() {
		return "<h2>Welcome to Spring Boot with RestAPI</h2>";
	}
	
	@RequestMapping(value = "plain",method = RequestMethod.GET,produces = MediaType.TEXT_PLAIN_VALUE)
	public String sayPlain() {
		return "<h2>Welcome to Spring Boot with RestAPI</h2>";
	}
	
	@RequestMapping(value = "xml",method = RequestMethod.GET,produces = MediaType.TEXT_XML_VALUE)
	public String sayXML() {
		return "<h2>Welcome to Spring Boot with RestAPI</h2>";
	}
}
