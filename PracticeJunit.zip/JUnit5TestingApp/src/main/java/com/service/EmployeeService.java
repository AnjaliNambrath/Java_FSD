package com.service;

import java.util.ArrayList;
import java.util.List;

import com.bean.Employee;

public class EmployeeService {

	public String checkUser(String emailid, String password) {
		if(emailid.equals("anu@gmail.com") && password.equals("123")) {
			return "success";
		}
		else {
			return "failure";
		}
	}
	
	public Employee getEmployee() {
		Employee emp = new Employee();
		emp.setId(1);
		emp.setName("Arun");
		emp.setSalary(12000);
		return emp;
	}
	
	public List<Employee> listOfEmployee(){
		List<Employee> list = new ArrayList<Employee>();
		Employee emp = new Employee();
		emp.setId(2);
		emp.setName("Varun");
		emp.setSalary(22000);
		Employee emp1 = new Employee();
		emp1.setId(3);
		emp1.setName("Frun");
		emp1.setSalary(19000);
		list.add(emp1);
		list.add(emp);
		return list;
	}
	
	public float passEmployeeObject(Employee emp) {
		//with condition
		return emp.getSalary()+500;
	}
}
