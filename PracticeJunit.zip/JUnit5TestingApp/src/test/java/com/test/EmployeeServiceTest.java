package com.test;

import static org.junit.jupiter.api.Assertions.*;

import java.util.List;

import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.bean.Employee;
import com.service.EmployeeService;

class EmployeeServiceTest {

	@Test
	@DisplayName("Check User Details Testing")
	void testCheckUser() {
		//fail("Not yet implemented");
		EmployeeService es = new EmployeeService();
		String result = es.checkUser("anu@gmail.com", "123");
		assertEquals("success", result);
		
		String result1 = es.checkUser("an@gmail.com", "12234");
		assertEquals("failure", result1);
	}

	@Test
	//@Disabled		//to disable a test
	void testGetEmployee() {
		//fail("Not yet implemented");
		EmployeeService es = new EmployeeService();
		Employee emp = es.getEmployee();
		assertNotNull(emp);
		assertEquals(1, emp.getId());
		assertEquals("Arun", emp.getName());
		assertEquals(12000, emp.getSalary());
	}

	@Test
	void testListOfEmployee() {
		//fail("Not yet implemented");
		EmployeeService es = new EmployeeService();
		List<Employee> list = es.listOfEmployee();
		assertEquals(2, list.size());
	}

	@Test
	void testPassEmployeeObject() {
		//fail("Not yet implemented");
		EmployeeService es = new EmployeeService();
		Employee emp = new Employee();
		emp.setId(2);
		emp.setName("Varun");
		emp.setSalary(22000);
		float updatedsalary = es.passEmployeeObject(emp);
		assertEquals(22500, updatedsalary);
		
	}

}
