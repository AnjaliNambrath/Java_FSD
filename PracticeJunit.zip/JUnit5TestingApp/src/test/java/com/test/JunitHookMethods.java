package com.test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class JunitHookMethods {

	@BeforeAll
	static void setUpBeforeClass() throws Exception {
		System.out.println("Before all tests");
	}

	@AfterAll
	static void tearDownAfterClass() throws Exception {
		System.out.println("After all tests");
	}

	@BeforeEach
	void setUp() throws Exception {
		System.out.println("Before each test method");
	}

	@AfterEach
	void tearDown() throws Exception {
		System.out.println("After each test method");
	}

	@Test
	void test() {
		//fail("Not yet implemented");
		System.out.println("First test method");
	}
	
	@Test
	void test1() {
		//fail("Not yet implemented");
				System.out.println("Second test method");
	}

}
