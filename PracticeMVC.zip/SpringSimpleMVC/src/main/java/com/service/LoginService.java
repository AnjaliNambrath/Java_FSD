package com.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bean.Login;
import com.dao.LoginDao;

@Service
public class LoginService {
	//LoginDao ld = new LoginDao();
	
	@Autowired
	LoginDao logindao;		//DI for logindao
	public String signIn(Login login) {
		if(logindao.signIn(login)>0) {
			return "success";
		}
		else {
			return "failure";
		}
	}
	
	public String signUp(Login login) {
		if(logindao.signUp(login)>0) {
			return "Account Created Successfully";
		}
		else {
			return "Account Didnt Created";
		}
	}
	

}
