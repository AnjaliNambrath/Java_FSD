package com;

import java.util.Iterator;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class DemoTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\anjal\\eclipse-workspace\\JavaFSD_Phase5\\chromedriver.exe");
		WebDriver wd = new ChromeDriver();
		wd.get("http://127.0.0.1:5500/index.html");		//load static or dynamic website
//		String titleTagContent = wd.getTitle();
//		String url = wd.getCurrentUrl();
//		String pageContent = wd.getPageSource();
//		System.out.println(pageContent);
//		System.out.println(url);
//		System.out.println(titleTagContent);
		
		WebElement h2TagRef = wd.findElement(By.tagName("h2"));
		System.out.println(h2TagRef.getTagName()+" = "+h2TagRef.getText());
		WebElement pTagRef = wd.findElement(By.tagName("p"));
		System.out.println(pTagRef.getTagName()+" = "+pTagRef.getText());
		WebElement divTagRef = wd.findElement(By.tagName("div"));
		System.out.println(divTagRef.getTagName()+" = "+divTagRef.getText());
		
		List<WebElement> listOfP = wd.findElements(By.tagName("p"));
		Iterator<WebElement> it = listOfP.iterator();
		while(it.hasNext()) {
			WebElement ww = it.next();
			System.out.println(ww.getTagName()+" = "+ww.getText());
		}
		
		WebElement divwithId = wd.findElement(By.id("abc"));
		System.out.println(divwithId.getTagName()+" = "+divwithId.getText());
		
		wd.close();
	}

}
