package com;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class LoginTest {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\anjal\\eclipse-workspace\\JavaFSD_Phase5\\chromedriver.exe");
		WebDriver wd = new ChromeDriver();
		wd.get("http://127.0.0.1:5500/login.html");
//		String SourceCurrentPagePath = wd.getCurrentUrl();
//		System.out.println(SourceCurrentPagePath);
//		WebElement emailRef = wd.findElement(By.id("n1"));
//		WebElement passRef = wd.findElement(By.id("n2"));
//		emailRef.sendKeys("rag@gmail.com");
//		passRef.sendKeys("123");
//		WebElement subButRef = wd.findElement(By.id("b1"));
//		subButRef.click();
//		String TargetCurrentPagePath = wd.getCurrentUrl();
//		System.out.println(TargetCurrentPagePath);
//		WebElement h2TagRef = wd.findElement(By.tagName("h2"));
//		System.out.println(h2TagRef.getText());
//		WebElement resetButRef = wd.findElement(By.id("b2"));
//		resetButRef.click();
		
//		//email validation
//		WebElement emailRef = wd.findElement(By.id("n1"));
//		WebElement passRef = wd.findElement(By.id("n2"));
//		WebElement subButRef = wd.findElement(By.id("b1"));
//		subButRef.click();
//		Alert alertRef = wd.switchTo().alert();		//give alert box ref
//		System.out.println(alertRef.getText());		//alert box content
//		alertRef.accept();
//		wd.close();
		
//		//password validation
//		WebElement emailRef = wd.findElement(By.id("n1"));
//		emailRef.sendKeys("rag@gmail.com");
//		WebElement passRef = wd.findElement(By.id("n2"));
//		WebElement subButRef = wd.findElement(By.id("b1"));
//		subButRef.click();
//		Alert alertRef = wd.switchTo().alert();		//give alert box ref
//		System.out.println(alertRef.getText());		//alert box content
//		alertRef.accept();
//		wd.close();
		
		//success
		WebElement emailRef = wd.findElement(By.id("n1"));
		emailRef.sendKeys("raj@gmail.com");
		WebElement passRef = wd.findElement(By.id("n2"));
		passRef.sendKeys("123");
		WebElement subButRef = wd.findElement(By.id("b1"));
		subButRef.click();
		Alert alertRef = wd.switchTo().alert();		//give alert box ref
		System.out.println(alertRef.getText());		//alert box content
		alertRef.accept();
		wd.close();
	}

}
