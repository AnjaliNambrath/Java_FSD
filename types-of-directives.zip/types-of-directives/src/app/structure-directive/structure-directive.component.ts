import { Component, OnInit } from '@angular/core';
import { Employee } from '../employee';

@Component({
  selector: 'app-structure-directive',
  templateUrl: './structure-directive.component.html',
  styleUrls: ['./structure-directive.component.css']
})
export class StructureDirectiveComponent implements OnInit {
  f1:boolean = true;
  f2:boolean = false;
  f3:boolean = false;
  f4:boolean = false;
  b1:string = "Show";
  num1:number[]=[12,13,14,15,16];
  names:string[]=["A","B","C"];

  employees:Array<Employee>=[]; //array object


  constructor() { }

  //it is a life cycle method which will get called automatically after constructor
  //this func only called once which is used to do some initialization
  ngOnInit(): void {
    //class style model
    // let emp1 = new Employee(100,"Raj",12000);
    // let emp2 = new Employee(101,"Ravi",13000);
    // let emp3 = new Employee(102,"Shiva",15000);
    // this.employees.push(emp1);
    // this.employees.push(emp2);
    // this.employees.push(emp3);

    //interface style model
    let emp1:Employee = {id:101,name:"Ravi",salary:12000}
    let emp2:Employee = {id:102,name:"Navi",salary:15000}
    let emp3:Employee = {id:103,name:"Havi",salary:19000}
    this.employees.push(emp1);
    this.employees.push(emp2);
    this.employees.push(emp3);

  }
  
  addEmployeeDetails(idRef:any,nameRef:any,salaryRef:any){
    let idValue = idRef.value;
    let nameValue = nameRef.value;
    let salaryValue = salaryRef.value;
    let emp:Employee={id:idValue,name:nameValue,salary:salaryValue};
    this.employees.push(emp);
    idRef.value="";
    nameRef.value="";
    salaryRef.value="";
  }

  changeValue(){
    this.f3 = true;
  }

  toggle(){
    if(this.f4){
      this.f4 = false;
      this.b1 = "Show";
    }
    else{
      this.f4 = true;
      this.b1 = "Hide";
    }
  }
}
