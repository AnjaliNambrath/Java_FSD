// export class Employee {
//     constructor(public id:number,
//         public name:string,
//         public salary:number){}
// }

export interface Employee{
    id : number;
    name : string;
    salary : number;
}
