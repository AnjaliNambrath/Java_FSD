package com;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration						//same as bean.xml file
@ComponentScan(basePackages = "com")	//same as <context:component-scan base-package="com"></context:component-scan>
public class MyConfiguration {
	@Bean(name = "p")			//we are creating object but it is maintained by container
	public Product get_instance() {
		Product pp = new Product();
		return pp;
	}
}
