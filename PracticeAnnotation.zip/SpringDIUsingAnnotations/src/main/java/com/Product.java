package com;

public class Product {
	public void ProductDetails() {
		System.out.println("get Product Details");
	}
}
