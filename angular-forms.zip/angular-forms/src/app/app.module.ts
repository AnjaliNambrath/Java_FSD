import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent } from './app.component';
import { TdfLoginpageComponent } from './tdf-loginpage/tdf-loginpage.component';
import { MdfLoginpageComponent } from './mdf-loginpage/mdf-loginpage.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { LoginService } from './login.service';

@NgModule({
  declarations: [
    AppComponent,
    TdfLoginpageComponent,
    MdfLoginpageComponent
  ],
  imports: [
    BrowserModule,FormsModule,ReactiveFormsModule
  ],
  providers: [LoginService],    //providing details about service class
  bootstrap: [AppComponent]
})
export class AppModule { }
