import { Component, OnInit } from '@angular/core';
import {FormControl, FormGroup, Validators } from '@angular/forms';
import { CustomService } from '../custom.service';
import { LoginService } from '../login.service';

@Component({
  selector: 'app-mdf-loginpage',
  templateUrl: './mdf-loginpage.component.html',
  styleUrls: ['./mdf-loginpage.component.css']
})
export class MdfLoginpageComponent implements OnInit {
  loginRef = new FormGroup({
    email:new FormControl("",Validators.required),
    pass:new FormControl("",Validators.required)
  });

  msg:string=""
  constructor(public ls:LoginService) { }

  ngOnInit(): void {
  }

  checkUser(){
    let login = this.loginRef.value;
    //console.log(login);


    // if (login.email=="raj@gmail.com" && login.pass=="123") {
    //   this.msg = "Successful Login"
    // } else {
    //   this.msg = "Failure! Try Again !!"
    // }

    // let cs = new CustomService();
    // this.msg = cs.checkUserDetails(login);
    
    this.msg=this.ls.checkUserDetails(login);

    this.loginRef.reset();
  }

}
