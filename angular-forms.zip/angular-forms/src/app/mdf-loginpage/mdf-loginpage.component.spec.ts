import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MdfLoginpageComponent } from './mdf-loginpage.component';

describe('MdfLoginpageComponent', () => {
  let component: MdfLoginpageComponent;
  let fixture: ComponentFixture<MdfLoginpageComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ MdfLoginpageComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(MdfLoginpageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
