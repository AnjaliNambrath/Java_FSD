import { Injectable } from "@angular/core";

@Injectable()
export class LoginService{
    checkUserDetails(login:any):string{
        if(login.email=="raj@gmail.com" && login.pass=="123"){
          return "Successfull Login"
        }
        else{
          return "Falure! Try Again!!!"
        }
      }
}