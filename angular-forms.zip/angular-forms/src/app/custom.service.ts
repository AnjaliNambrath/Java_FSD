export class CustomService{
    checkUserDetails(login:any):string{
        if(login.email=="raj@gmail.com" && login.pass=="123"){
          return "Successfull Login"
        }
        else{
          return "Falure! Try Again!!!"
        }
      }
}