import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TdfLoginpageComponent } from './tdf-loginpage.component';

describe('TdfLoginpageComponent', () => {
  let component: TdfLoginpageComponent;
  let fixture: ComponentFixture<TdfLoginpageComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TdfLoginpageComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(TdfLoginpageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
