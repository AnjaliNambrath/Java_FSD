import { Component, OnInit } from '@angular/core';
import { CustomService } from '../custom.service';
import { LoginService } from '../login.service';

@Component({
  selector: 'app-tdf-loginpage',
  templateUrl: './tdf-loginpage.component.html',
  styleUrls: ['./tdf-loginpage.component.css']
})
export class TdfLoginpageComponent implements OnInit {
  msg:string=""
  constructor(public ls:LoginService) { }       //DI for service class

  ngOnInit(): void {
  }

  checkUser(loginRef:any){
    //console.log(loginRef)
    let login = loginRef.value;
    //console.log(login);


    // if(login.email=="raj@gmail.com" && login.pass=="123"){
    //   this.msg="Successfull Login"
    // }
    // else{
    //   this.msg="Falure! Try Again!!!"
    // }

    // let cs = new CustomService();
    // this.msg = cs.checkUserDetails(login);

    this.msg = this.ls.checkUserDetails(login);
    loginRef.reset();
  }

}
